---
title: Play
media_order: wizard-hat-first_edit.png
---

# This game is in development. 

### Development builds available for play testing.

##### Builds

* [Download for Windows](/beta/moonreporter_windows.zip). Run the .exe to play.
* [Download for Mac](/beta/moonreporter_mac.zip).
* [Play in the browser](/beta). This version has the worst performance.

##### Controls
* Move: A, D
* Jump: W or K
* Fire: Left-Ctrl or L
* Do not use the **space bar**. I think it's mapped to multiple buttons.

![Wizard Hat](wizard-hat-first_edit.png)

