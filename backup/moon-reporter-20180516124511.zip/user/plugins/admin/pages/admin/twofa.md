---
title: 2-Factor Authentication

form:               
    fields:
        2fa_instructions:
            type: display
            markdown: true
            content: PLUGIN_ADMIN.2FA_INSTRUCTIONS
        2fa_code:
            type: text
            autofocus: true
            placeholder: PLUGIN_ADMIN.2FA_CODE_INPUT 
---
